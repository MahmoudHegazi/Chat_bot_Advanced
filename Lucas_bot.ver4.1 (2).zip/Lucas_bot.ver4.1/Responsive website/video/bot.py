x = input("Enter Your Name")
if x != "":
    print("Hello " + str(x))
    
